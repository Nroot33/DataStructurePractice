
public interface Queue {
	
	public void add(int n);

	public Object first();

	public Object remove();

	public int size();

}
