
public interface Point {
	public double getX();
	public void setX(double x);
	public double getY();
	public void setY(double y);
	public void print();
	public void moveTo(double n, double m) ;
	public void scaleTo(double n);

}
