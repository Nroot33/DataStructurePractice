
public class MyPointTest {
	public static void main(String args[]) {
		MyPoint p = new MyPoint(-1,3);
		p.print();
		p.moveTo(2, -5);
		p.print();
		p.scaleTo(-2);
		p.print();
		p.scaleTo(2);
		p.print();
	
		

	}
}
