
public interface Client {
	public void setStartTime(int t);
	public void setStopTime(int t);
}
