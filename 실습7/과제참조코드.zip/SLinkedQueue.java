public class SLinkedQueue implements Queue{
	
	private class Node {
		Object object;
		Node next;
		Node(Object object) { this.object=object; }
		Node(Object object, Node next) {
			this.object = object;
			this.next = next;
		}
	}
	
	private Node head;
	private Node rear;
	private int size;
	
	@Override
	public void add(Object object) {
	
	}

	@Override
	public Object first() {
	
	}
	
	@Override
	public Object remove() {
	
	}

	@Override
	public int size() {
		return this.size;
	}
	
	public boolean empty() {
		return this.head == null;
	}
	
	
	public ArrayQueue toArrayQueue() {
	
	}
	
	public void print() {
		System.out.println(this.toString()+"\n");
	}
	
	public String toString() {
		String str = " * Singly Linked Queue = head";
		
		Node ptr = this.head;
		
		while(ptr != null) {
			str = str + " -> " + ptr.object;
			ptr = ptr.next;
		}
		return str;
	}
}
